#include <iostream>
#include <fstream>
#include <windows.h>

#include <SFML/Network.hpp>
#include <SFML/Network/IpAddress.hpp>

#include <process.h>
#include <Tlhelp32.h>
#include <winbase.h>
#include <string.h>

#include <stdio.h>
#pragma comment(lib, "user32.lib")

static bool porta_aberta(const std::string& ip, int port)
{
    return (sf::TcpSocket().connect(ip, port) == sf::Socket::Done);
}

void matar_processo(const char *nome)
{

HANDLE hSnapShot = CreateToolhelp32Snapshot(TH32CS_SNAPALL, NULL);
PROCESSENTRY32 pEntry;
pEntry.dwSize = sizeof (pEntry);
BOOL hRes = Process32First(hSnapShot, &pEntry);
while (hRes)
{
if (strcmp(pEntry.szExeFile, nome) == 0)
{
HANDLE hProcess = OpenProcess(PROCESS_TERMINATE, 0,
(DWORD) pEntry.th32ProcessID);
if (hProcess != NULL)
{
TerminateProcess(hProcess, 9);
CloseHandle(hProcess);
}
}
hRes = Process32Next(hSnapShot, &pEntry);
}
CloseHandle(hSnapShot);
}

int main()
{
    int menu;
     std::string menu2;

    do{
        system("cls");
        std::cout << ">>>>>>>>>>>>>>>>>>>>> Bem Vindo a Ferramenta Heimdall v0.2 <<<<<<<<<<<<<<<<<<<<<" << std::endl;
         std::cout<<""<<std::endl;
        std::cout << " Criada por: " << std::endl;
        std::cout << " Gilmar Reis dos Santos Borges Junior " << std::endl;
        std::cout<<""<<std::endl;
        std::cout<<"                                     MENU                                         "<<std::endl;
        std::cout<<" -> 1 Scanner"<<std::endl;
        std::cout<<" -> 2 Bloqueio de Host"<<std::endl;
        std::cout<<" -> 3 Bloqueio de APP"<<std::endl;
        std::cout<<" -> 4 Bloqeuio de Interface USB"<<std::endl;
        std::cout<<" -> 5 Visualizar Processos"<<std::endl;
        std::cout<<" -> 6 Matar Processos"<<std::endl;
        std::cout<<" -> 7 Usuario e Maquina"<<std::endl;
        std::cout<<" -> 8 Logoff"<<std::endl;
        std::cout<<" -> 9 Backup "<<std::endl;
        std::cout<<" -> 0 Sair "<<std::endl;
        std::cout<<""<<std::endl;
        std::cout<<"Porfavor Escolha um item -> ";
        std::cin>>menu;

        if (menu == 1 )
           {do{

           system("cls");
             int  a,b,c;
    std::string ip;

std::cout<<"Digite o Ip -> ";
std::cin>>ip;

system("cls");
std::cout<<"Digite a Primeira Porta -> ";
std::cin>>a;
system("cls");
std::cout<<"Digite a Segunda Porta -> ";
std::cin>>b;
system("cls");

c=b+1;
for(int port = a;  port < c; ++port)

   // for( )

    if (porta_aberta(ip, port))
        std::cout <<" -> "<<ip<<" Porta "<<port<< " Aberta" << std::endl;
    else
        std::cout <<" -> "<<ip<<" Porta "<<port<< " Fechada" << std::endl;
         std::cout<<" "<<std::endl;
            std::cout<<" -> Deseja Proseguir <s/n>"<<std::endl;
             std::cin>>menu2;
           }while(menu2 !="n");

        }
         if (menu == 2 )
           {do{

           system("cls");
            std::cout<<" -> Por Favor escolha um item"<<std::endl;
            std::cout<<" -> A Digitando o nome "<<std::endl;
            std::cout<<" -> B Usando um arquivo com os nomes "<<std::endl;
            std::cout<<" -> S Para Sair  "<<std::endl;
            std::cout<<""<<std::endl;
             std::cin>>menu2;
            if(menu2 == "a"){
                do{do{
                        system("cls");
                     char site[20],ch;
    std::ifstream in;
    std::ofstream out;

    std::cout <<" Entre com o Nome ou IP do Site para Bloqueio" << std::endl;
    std::cin>>site;
    out.open("C:\\Windows\\System32\\drivers\\etc\\hosts",std::ios::app);
    if(!out)
        std::cout<<"N�o foi possivel bloquear o site"<<std::endl;
    else{

        out<<"127.0.0.1"<<" "<<site;
        std::cout<<site;
        std::cout<<" Bloqueado";
    }
    out.close();
    std::cout<<"  "<<std::endl;
    std::cout<<" -> Deseja continuar <s/n> "<<std::endl;
    std::cin>>menu2;
                }while (menu2 != "n");
                }while(menu == 3);
            }if(menu2 == "b"){
                do{do{
                        system("cls");
                        char tr[100];

    std::cout<<"Digite o local do arquivo"<<std::endl;
    std::cin>>tr;
    std::ifstream in(tr);

    std::ofstream out("C:\\Windows\\System32\\drivers\\etc\\hosts",std::ios::app);
    std::string str;
    while(getline(in,str))
        out<<str<<std::endl;
        std::cout<<""<<std::endl;
        std::cout<<" -> Deseja continuar?"<<std::endl;
        std::cin>>menu2;
                }while(menu2 !="n");
                }while(menu2 == "s");
            }

             std::cout<<" "<<std::endl;
            std::cout<<" -> Deseja Continuar no programa <s/n>"<<std::endl;
             std::cin>>menu2;
           }while(menu2 !="n");

        }
        if(menu ==3)
        {do{

         system("cls");

HKEY key;
if (RegOpenKey(HKEY_CURRENT_USER, TEXT ("Software\\Microsoft\\Windows\\CurrentVersion\\Policies"), &key) != ERROR_SUCCESS)
{
    std::cout<<"Chave N�o Encontrada"<<std::endl;
}

DWORD valor = 1;
char tec[20];
std::cout<<"Digite o nome do programa que deseja bloquear "<<std::endl;
std::cin>>tec;
    if (RegSetValueEx(key, TEXT("DisallowRun"), 0, REG_DWORD, (const BYTE*)&valor,  sizeof(DWORD)) != ERROR_SUCCESS)
    {
        RegCloseKey(key);



}
if (RegOpenKey(HKEY_CURRENT_USER, TEXT ("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\DisallowRun"), &key) != ERROR_SUCCESS)
{
    RegCreateKey(HKEY_CURRENT_USER, TEXT ("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\DisallowRun"), &key);


}


 if (RegSetValueEx(key, TEXT("Bloqueado"), 0, REG_SZ, (LPBYTE) tec, strlen(tec) *sizeof(char)) != ERROR_SUCCESS)
    {
        RegCloseKey(key);
  std::cout<<" -> Erro em bloquear o programa"<<std::endl;
  std::cout<<" -> Temte executar o Heimdall como Administrador "<<std::endl;


}
if (RegOpenKey(HKEY_CURRENT_USER, TEXT ("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer"), &key) != ERROR_SUCCESS)
{
    RegCreateKey(HKEY_CURRENT_USER, TEXT ("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\"), &key);



}

 if (RegSetValueEx(key, TEXT("DisallowRun"), 0, REG_DWORD, (const BYTE*)&valor,  sizeof(DWORD)) != ERROR_SUCCESS)
    {
        RegCloseKey(key);

}




        std::cout<<" "<<std::endl;
        std::cout<<" -> Deseja continuar? <s/n>"<<std::endl;
        std::cin>>menu2;
        }while(menu2 !="n");

        }
        if(menu ==4)
            {do{
                system("cls");

     HKEY key;
    if (RegOpenKey(HKEY_LOCAL_MACHINE, TEXT ("System\\CurrentControlSet\\Services\\USBSTOR"), &key) != ERROR_SUCCESS)
{
    std::cout<<"Chave N�o Encontrada"<<std::endl;


}
std::string tec;
std::cout<<"Deseja Bloquear a Interface USB <s/n>"<<std::endl;
std::cin>>tec;

if (tec == "s"){
DWORD valor = 4;
  if (RegSetValueEx(key, TEXT("Start"), 0, REG_DWORD, (const BYTE*)&valor,  sizeof(DWORD)) != ERROR_SUCCESS)
    {
        RegCloseKey(key);
        std::cout<<"N�o foi possivel criar o valor na Chave"<<std::endl;

}
}
if (tec == "n"){
    DWORD valor = 3;
  if (RegSetValueEx(key, TEXT("Start"), 0, REG_DWORD, (const BYTE*)&valor,  sizeof(DWORD)) != ERROR_SUCCESS)
    {
        RegCloseKey(key);
        std::cout<<"N�o foi possivel criar o valor na Chave"<<std::endl;

}

}
std::cout<<" "<<std::endl;
std::cout<<" -> Deseja continuar <s/n>"<<std::endl;
std::cin>>menu2;
            }while(menu2 !="n");

        }
        if(menu==5)
        {do{


        std::cout<<" "<<std::endl;
std::cout<<" -> Deseja continuar <s/n>"<<std::endl;
std::cin>>menu2;
        }while(menu2 != "n");

        }
        if(menu==6)
        {do{

            system("cls");
        std::string tec;

    std::cout<<"Digite o nome do processo que deseja Matar "<<std::endl;
    std::cin>>tec;
    char * mat = new char[tec.size() + 1];
std::copy(tec.begin(), tec.end(), mat);
mat[tec.size()] = '\0';
    matar_processo(mat);
    delete[] mat;

        std::cout<<" "<<std::endl;
std::cout<<" -> Deseja continuar <s/n>"<<std::endl;
std::cin>>menu2;
        }while(menu2 != "n");
        }
        if(menu==7)
        {do{

           system("cls");
        #define INFO_BUFFER_SIZE 32767
char infoBuf[INFO_BUFFER_SIZE];
DWORD bufCharCount = INFO_BUFFER_SIZE;
GetComputerName(infoBuf, &bufCharCount);
std::cout<<"Nome do Computador -> "<<infoBuf<<std::endl;
GetUserName(infoBuf, &bufCharCount);
std::cout<<"Nome do Usuario -> "<<infoBuf<<std::endl;

          std::cout<<" "<<std::endl;
std::cout<<" -> Deseja continuar <s/n>"<<std::endl;
std::cin>>menu2;
        }while(menu2 !="n");

        }
        if(menu ==8)
        {do{

        system("cls");
      ExitWindows(0,0);

          std::cout<<" "<<std::endl;
std::cout<<" -> Deseja continuar <s/n>"<<std::endl;
std::cin>>menu2;
        }while(menu2 !="n");

        }

        if (menu==9)
        {do{

            system("cls");
        std::cout<<"Deseja Fazer o backup do Sistema <s/n>"<<std::endl;
std::string s;
std::cin>>s;
if (s=="s"){
    system("wbAdmin start backup -backupTarget:E: -include:C: -allCritical -quiet");
}

         std::cout<<" "<<std::endl;
std::cout<<" -> Deseja continuar <s/n>"<<std::endl;
std::cin>>menu2;
        }while(menu2 !="n");

        }



    }
    while (menu != 0);
system("cls");
    return 0;
}
