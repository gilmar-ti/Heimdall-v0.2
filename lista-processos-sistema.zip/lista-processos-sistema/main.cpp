#include <windows.h>
#include <tlhelp32.h>
#include <iostream>

//  Forward declarations:
BOOL GetProcessList( );
BOOL ListProcessModules( DWORD dwPID );
BOOL ListProcessThreads( DWORD dwOwnerPID );


int main( void )
{
  GetProcessList( );
  return 0;
}

BOOL GetProcessList( )
{
  HANDLE hProcessSnap;
  HANDLE hProcess;
  PROCESSENTRY32 pe32;
  DWORD dwPriorityClass;

  // Take a snapshot of all processes in the system.
  hProcessSnap = CreateToolhelp32Snapshot( TH32CS_SNAPPROCESS, 0 );
  if( hProcessSnap == INVALID_HANDLE_VALUE )
  {
    std::cout<<" !! ERRO !! CreateToolhelp32Snapshot (of processes)";
    return( FALSE );
  }

  // Set the size of the structure before using it.
  pe32.dwSize = sizeof( PROCESSENTRY32 );

  // Retrieve information about the first process,
  // and exit if unsuccessful
  if( !Process32First( hProcessSnap, &pe32 ) )
  {
    std::cout<<" !! ERRO !! Process32First"; // show cause of failure
    CloseHandle( hProcessSnap );          // clean the snapshot object
    return( FALSE );
  }

  // Now walk the snapshot of processes, and
  // display information about each process in turn
  do
  {
    std::cout<<""<<std::endl;
    std::cout<<"PROCESS NAME:  "<< pe32.szExeFile<<std::endl;


    // Retrieve the priority class.
    dwPriorityClass = 0;
    hProcess = OpenProcess( PROCESS_ALL_ACCESS, FALSE, pe32.th32ProcessID );
    if( hProcess == NULL )
      std::cout<<" !! ERRO !! OpenProcess";
    else
    {
      dwPriorityClass = GetPriorityClass( hProcess );
      if( !dwPriorityClass )
        std::cout<<" !! ERRO !! GetPriorityClass";
      CloseHandle( hProcess );
    }

    std::cout<<"  Process ID        = "<< pe32.th32ProcessID<<std::endl;
    std::cout<<"  Thread count      = "<<   pe32.cntThreads<<std::endl;
    std::cout<<"  Parent process ID = "<< pe32.th32ParentProcessID <<std::endl;
    std::cout<<"  Priority base     = "<< pe32.pcPriClassBase <<std::endl;
    if( dwPriorityClass )
      std::cout<<"  Priority class    = "<< dwPriorityClass<<std::endl ;

    // List the modules and threads associated with this process
    ListProcessModules( pe32.th32ProcessID );
    ListProcessThreads( pe32.th32ProcessID );

  } while( Process32Next( hProcessSnap, &pe32 ) );

  CloseHandle( hProcessSnap );
  return( TRUE );
}


BOOL ListProcessModules( DWORD dwPID )
{
  HANDLE hModuleSnap = INVALID_HANDLE_VALUE;
  MODULEENTRY32 me32;

  // Take a snapshot of all modules in the specified process.
  hModuleSnap = CreateToolhelp32Snapshot( TH32CS_SNAPMODULE, dwPID );
  if( hModuleSnap == INVALID_HANDLE_VALUE )
  {
    std::cout<<" !! ERRO !! = CreateToolhelp32Snapshot (of modules)";
    return( FALSE );
  }

  // Set the size of the structure before using it.
  me32.dwSize = sizeof( MODULEENTRY32 );

  // Retrieve information about the first module,
  // and exit if unsuccessful
  if( !Module32First( hModuleSnap, &me32 ) )
  {
    std::cout<<" !! ERRO !! = Module32First";  // show cause of failure
    CloseHandle( hModuleSnap );           // clean the snapshot object
    return( FALSE );
  }

  // Now walk the module list of the process,
  // and display information about each module
  do
  {
      std::cout<<""<<std::endl;
    std::cout<<"     MODULE NAME:  "<<   me32.szModule <<std::endl;
    std::cout<<"     Executable     = "<<   me32.szExePath <<std::endl;
    std::cout<<"     Process ID     = "<<   me32.th32ProcessID <<std::endl;
    std::cout<<"     Ref count (g)  = "<<   me32.GlblcntUsage <<std::endl;
    std::cout<<"     Ref count (p)  = "<<   me32.ProccntUsage <<std::endl;
    std::cout<<"     Base address   = "<< (DWORD) me32.modBaseAddr <<std::endl;
    std::cout<<"     Base size      = "<<            me32.modBaseSize <<std::endl;

  } while( Module32Next( hModuleSnap, &me32 ) );

  CloseHandle( hModuleSnap );
  return( TRUE );
}

BOOL ListProcessThreads( DWORD dwOwnerPID )
{
  HANDLE hThreadSnap = INVALID_HANDLE_VALUE;
  THREADENTRY32 te32;

  // Take a snapshot of all running threads
  hThreadSnap = CreateToolhelp32Snapshot( TH32CS_SNAPTHREAD, 0 );
  if( hThreadSnap == INVALID_HANDLE_VALUE )
    return( FALSE );

  // Fill in the size of the structure before using it.
  te32.dwSize = sizeof(THREADENTRY32);

  // Retrieve information about the first thread,
  // and exit if unsuccessful
  if( !Thread32First( hThreadSnap, &te32 ) )
  {
    std::cout<<" !! ERRO !! Thread32First"; // show cause of failure
    CloseHandle( hThreadSnap );          // clean the snapshot object
    return( FALSE );
  }

  // Now walk the thread list of the system,
  // and display information about each thread
  // associated with the specified process
  do
  {
    if( te32.th32OwnerProcessID == dwOwnerPID )
    {
        std::cout<<""<<std::endl;
      std::cout<<"     THREAD ID      = "<< te32.th32ThreadID <<std::endl;
      std::cout<<"     Base priority  = "<< te32.tpBasePri<<std::endl ;
      std::cout<<"     Delta priority = "<< te32.tpDeltaPri <<std::endl;

    }
  } while( Thread32Next(hThreadSnap, &te32 ) );

  CloseHandle( hThreadSnap );
  return( TRUE );
}


